import React from 'react'
import "./stat.css"

const Stats = () => {

    return <>
        <div className='container-fluid mx-0 px-0'>
            <div className='row'>
                <div className='col-12'>
                    <p>Stats</p>
                </div>
            </div>
        </div>
    </>
}

export default Stats
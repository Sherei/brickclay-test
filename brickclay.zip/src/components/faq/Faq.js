import React from 'react'
import "./faq.css"
const Faq = () => {
    return <>
    <div className='container-fluid mx-0 px-0'>
        <div className='row'>
            <div className='col-12'>
                <p>Faq</p>
            </div>
        </div>
    </div>
  
  </>
}

export default Faq
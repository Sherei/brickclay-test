import Hero from "./components/hero/Hero"
import Experience from "./components/experience/Experience";
import About from "./components/about/About";
import Faq from "./components/faq/Faq";
import Stats from "./components/stat/Stats";
import Footer from "./components/footer/Footer";

function App() {
  
  return <>
    <div style={{ overflow: "hidden" }}>
      <Hero />
      <Experience />
      <About />
      <Faq />
      <Stats />
      <Footer />
    </div>
  </>
}

export default App;
